package lt.viko.eif.grupe.sport_api;

import lt.viko.eif.grupe.sport_api.model.Exercise;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class ExerciseTest {

    @Test
    public void testExerciseFields() {
        Exercise exercise = new Exercise();
        exercise.setName("Bench Press");
        exercise.setTargetMuscle("Chest");
        exercise.setEquipment("Barbell");
        exercise.setBodyPart("Upper body");
        exercise.setGifUrl("http://example.com/gif");

        assertEquals("Bench Press", exercise.getName());
        assertEquals("Chest", exercise.getTargetMuscle());
        assertEquals("Barbell", exercise.getEquipment());
        assertEquals("Upper body", exercise.getBodyPart());
        assertEquals("http://example.com/gif", exercise.getGifUrl());
    }
}
