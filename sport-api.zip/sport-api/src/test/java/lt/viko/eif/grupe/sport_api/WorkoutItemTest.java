package lt.viko.eif.grupe.sport_api;

import lt.viko.eif.grupe.sport_api.model.WorkoutItem;
import lt.viko.eif.grupe.sport_api.model.Workout;
import lt.viko.eif.grupe.sport_api.model.Exercise;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class WorkoutItemTest {

    @Test
    public void testWorkoutItemFields() {
        Workout workout = new Workout();
        Exercise exercise = new Exercise();

        WorkoutItem item = new WorkoutItem();
        item.setSets(4);
        item.setReps(10);
        item.setWeight(50.5);
        item.setWorkout(workout);
        item.setExercise(exercise);

        assertEquals(4, item.getSets());
        assertEquals(10, item.getReps());
        assertEquals(50.5, item.getWeight());
        assertEquals(workout, item.getWorkout());
        assertEquals(exercise, item.getExercise());
    }
}
