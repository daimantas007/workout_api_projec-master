package lt.viko.eif.grupe.sport_api;

import lt.viko.eif.grupe.sport_api.model.Workout;
import lt.viko.eif.grupe.sport_api.repository.WorkoutRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.server.LocalServerPort;
import org.springframework.http.*;
import org.springframework.web.client.RestTemplate;

import java.time.LocalDateTime;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
public class WorkoutControllerIntegrationTest {

    @LocalServerPort
    private int port;

    @Autowired
    private WorkoutRepository workoutRepository;

    private String baseUrl;
    private RestTemplate restTemplate;

    @BeforeEach
    public void setUp() {
        restTemplate = new RestTemplate();
        baseUrl = "http://localhost:" + port + "/workouts";
        workoutRepository.deleteAll(); // išvalom prieš kiekvieną testą
    }

    @Test
    public void testCreateAndGetWorkout() {
        Workout newWorkout = new Workout();
        newWorkout.setTitle("Integration Test Workout");
        newWorkout.setDate(LocalDateTime.now());

        ResponseEntity<Workout> postResponse = restTemplate.postForEntity(baseUrl, newWorkout, Workout.class);
        assertEquals(HttpStatus.OK, postResponse.getStatusCode());
        assertNotNull(postResponse.getBody());
        assertNotNull(postResponse.getBody().getId());

        // Tada patikrinam ar jis  įrašytas
        Long createdId = postResponse.getBody().getId();
        Workout saved = workoutRepository.findById(createdId).orElse(null);
        assertNotNull(saved);
        assertEquals("Integration Test Workout", saved.getTitle());
    }
}
