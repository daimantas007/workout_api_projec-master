package lt.viko.eif.grupe.sport_api;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.time.LocalDateTime;
import java.util.ArrayList;

import lt.viko.eif.grupe.sport_api.model.Workout;
import lt.viko.eif.grupe.sport_api.model.User;
import lt.viko.eif.grupe.sport_api.model.WorkoutItem;


import static org.junit.jupiter.api.Assertions.*;

public class WorkoutTest {

    private Workout workout;

    @BeforeEach
    public void setUp() {
        workout = new Workout();
        workout.setTitle("Leg Day");
        workout.setDate(LocalDateTime.now());
        workout.setUser(new User());
        workout.setItems(new ArrayList<>());
    }

    @Test
    public void testWorkoutInitialization() {
        assertNotNull(workout);
        assertEquals("Leg Day", workout.getTitle());
        assertNotNull(workout.getDate());
        assertNotNull(workout.getUser());
    }

    @Test
    public void testItemsListIsNotNull() {
        assertNotNull(workout.getItems(), "Workout items list should not be null");
        assertEquals(0, workout.getItems().size(), "Workout items list should be empty initially");

        WorkoutItem item = new WorkoutItem();
        workout.getItems().add(item);

        assertEquals(1, workout.getItems().size(), "Workout items list should contain one item after adding");
    }

    @Test
    public void testWorkoutSettersAndGetters() {
        Workout newWorkout = new Workout();
        newWorkout.setTitle("Push Day");

        assertEquals("Push Day", newWorkout.getTitle());
    }
}