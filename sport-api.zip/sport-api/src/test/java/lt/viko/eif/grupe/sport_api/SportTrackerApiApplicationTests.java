package lt.viko.eif.grupe.sport_api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SportTrackerApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
