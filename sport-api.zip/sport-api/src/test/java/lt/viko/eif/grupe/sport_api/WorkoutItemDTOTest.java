package lt.viko.eif.grupe.sport_api;

import lt.viko.eif.grupe.sport_api.model.WorkoutItemDTO;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class WorkoutItemDTOTest {

    @Test
    public void testWorkoutItemDTOFields() {
        WorkoutItemDTO dto = new WorkoutItemDTO();
        dto.setSets(3);
        dto.setReps(12);
        dto.setWeight(40.0);
        dto.setWorkoutId(1L);
        dto.setExerciseName("Squat");

        assertEquals(3, dto.getSets());
        assertEquals(12, dto.getReps());
        assertEquals(40.0, dto.getWeight());
        assertEquals(1L, dto.getWorkoutId());
        assertEquals("Squat", dto.getExerciseName());
    }
}
