package lt.viko.eif.grupe.sport_api;

import lt.viko.eif.grupe.sport_api.model.User;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class UserTest {

    @Test
    public void testUserFields() {
        User user = new User();
        user.setEmail("test@example.com");
        user.setPassword("secret123");

        assertEquals("test@example.com", user.getEmail());
        assertEquals("secret123", user.getPassword());
    }
}
