package lt.viko.eif.grupe.sport_api.controller;

import lt.viko.eif.grupe.sport_api.model.Workout;
import lt.viko.eif.grupe.sport_api.repository.WorkoutRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/workouts")
public class WorkoutController {

    @Autowired
    private WorkoutRepository workoutRepository;

    @GetMapping
    public List<Workout> getAllWorkouts() {
        return workoutRepository.findAll();
    }

    @GetMapping("/{id}")
    public Workout getWorkoutById(@PathVariable Long id) {
        Workout workout = workoutRepository.findById(id).orElse(null);
        if (workout != null) {
            workout.getItems().size();
        }
        return workout;
    }

    @PostMapping
    public Workout createWorkout(@RequestBody Workout workout) {
        return workoutRepository.save(workout);
    }

    @PutMapping("/{id}")
    public Workout updateWorkout(@PathVariable Long id, @RequestBody Workout updatedWorkout) {
        return workoutRepository.findById(id)
                .map(workout -> {
                    workout.setTitle(updatedWorkout.getTitle());
                    workout.setDate(updatedWorkout.getDate());
                    workout.setUser(updatedWorkout.getUser());
                    return workoutRepository.save(workout);
                })
                .orElse(null);
    }

    @DeleteMapping("/{id}")
    public void deleteWorkout(@PathVariable Long id) {
        workoutRepository.deleteById(id);
    }

    @GetMapping("/user/{userId}")
    public List<Workout> getWorkoutsByUserId(@PathVariable Long userId) {
        return workoutRepository.findByUserId(userId);
    }
}
