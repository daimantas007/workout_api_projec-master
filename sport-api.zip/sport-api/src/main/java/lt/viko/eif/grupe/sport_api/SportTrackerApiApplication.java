package lt.viko.eif.grupe.sport_api;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SportTrackerApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(SportTrackerApiApplication.class, args);
	}

}
