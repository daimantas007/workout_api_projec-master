package lt.viko.eif.grupe.sport_api.controller;

import lt.viko.eif.grupe.sport_api.model.Progress;
import lt.viko.eif.grupe.sport_api.repository.ProgressRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/progress")
public class ProgressController {

    @Autowired
    private ProgressRepository progressRepository;

    @GetMapping
    public List<Progress> getAllProgress() {
        return progressRepository.findAll();
    }

    @GetMapping("/{id}")
    public Progress getProgressById(@PathVariable Long id) {
        return progressRepository.findById(id).orElse(null);
    }

    @PostMapping
    public Progress createProgress(@RequestBody Progress progress) {
        return progressRepository.save(progress);
    }

    @PutMapping("/{id}")
    public Progress updateProgress(@PathVariable Long id, @RequestBody Progress updatedProgress) {
        return progressRepository.findById(id)
                .map(p -> {
                    p.setDate(updatedProgress.getDate());
                    p.setReps(updatedProgress.getReps());
                    p.setWeight(updatedProgress.getWeight());
                    p.setUser(updatedProgress.getUser());
                    p.setExercise(updatedProgress.getExercise());
                    return progressRepository.save(p);
                })
                .orElse(null);
    }

    @DeleteMapping("/{id}")
    public void deleteProgress(@PathVariable Long id) {
        progressRepository.deleteById(id);
    }
}
