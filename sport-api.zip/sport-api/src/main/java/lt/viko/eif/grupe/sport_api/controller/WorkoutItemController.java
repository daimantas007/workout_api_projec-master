package lt.viko.eif.grupe.sport_api.controller;

import lt.viko.eif.grupe.sport_api.model.Exercise;
import lt.viko.eif.grupe.sport_api.model.Workout;
import lt.viko.eif.grupe.sport_api.model.WorkoutItem;
import lt.viko.eif.grupe.sport_api.model.WorkoutItemDTO;
import lt.viko.eif.grupe.sport_api.repository.ExerciseRepository;
import lt.viko.eif.grupe.sport_api.repository.WorkoutItemRepository;
import lt.viko.eif.grupe.sport_api.repository.WorkoutRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/workout-items")
public class WorkoutItemController {

    @Autowired
    private WorkoutItemRepository workoutItemRepository;

    @Autowired
    private WorkoutRepository workoutRepository;

    @Autowired
    private ExerciseRepository exerciseRepository;

    @GetMapping
    public List<WorkoutItem> getAllWorkoutItems() {
        return workoutItemRepository.findAll();
    }

    @GetMapping("/{id}")
    public WorkoutItem getWorkoutItemById(@PathVariable Long id) {
        return workoutItemRepository.findById(id).orElse(null);
    }

    @PostMapping
    public WorkoutItem createWorkoutItem(@RequestBody WorkoutItemDTO itemDTO) {
        Workout workout = workoutRepository.findById(itemDTO.getWorkoutId()).orElse(null);
        if (workout == null) {
            throw new IllegalArgumentException("Invalid workout ID");
        }

        // Tikrinam ar pratimas yra DB, jei ne – sukuriam
        Exercise exercise = exerciseRepository.findByName(itemDTO.getExerciseName()).orElseGet(() -> {
            Exercise newExercise = new Exercise();
            newExercise.setName(itemDTO.getExerciseName());
            // gali papildyti daugiau laukų jei nori: targetMuscle, bodyPart ir t.t.
            return exerciseRepository.save(newExercise);
        });

        WorkoutItem item = new WorkoutItem();
        item.setSets(itemDTO.getSets());
        item.setReps(itemDTO.getReps());
        item.setWeight(itemDTO.getWeight());
        item.setWorkout(workout);
        item.setExercise(exercise);

        return workoutItemRepository.save(item);
    }


    @PutMapping("/{id}")
    public WorkoutItem updateWorkoutItem(@PathVariable Long id, @RequestBody WorkoutItem updatedItem) {
        return workoutItemRepository.findById(id)
                .map(item -> {
                    item.setReps(updatedItem.getReps());
                    item.setSets(updatedItem.getSets());
                    item.setWeight(updatedItem.getWeight());
                    item.setWorkout(updatedItem.getWorkout());
                    item.setExercise(updatedItem.getExercise());
                    return workoutItemRepository.save(item);
                })
                .orElse(null);
    }

    @DeleteMapping("/{id}")
    public void deleteWorkoutItem(@PathVariable Long id) {
        workoutItemRepository.deleteById(id);
    }

    @GetMapping("/workout/{workoutId}")
    public List<WorkoutItem> getItemsByWorkoutId(@PathVariable Long workoutId) {
        return workoutItemRepository.findByWorkoutId(workoutId);
    }
}
