package lt.viko.eif.grupe.sport_api.repository;

import lt.viko.eif.grupe.sport_api.model.WorkoutItem;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface WorkoutItemRepository extends JpaRepository<WorkoutItem, Long> {
    List<WorkoutItem> findByWorkoutId(Long workoutId);
}
