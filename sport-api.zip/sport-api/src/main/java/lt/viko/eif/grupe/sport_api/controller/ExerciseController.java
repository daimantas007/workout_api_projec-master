package lt.viko.eif.grupe.sport_api.controller;

import lt.viko.eif.grupe.sport_api.model.Exercise;
import lt.viko.eif.grupe.sport_api.repository.ExerciseRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/exercises")
public class ExerciseController {

    @Autowired
    private ExerciseRepository exerciseRepository;

    @GetMapping
    public List<Exercise> getAllExercises() {
        return exerciseRepository.findAll();
    }

    @GetMapping("/{id}")
    public Exercise getExerciseById(@PathVariable Long id) {
        return exerciseRepository.findById(id).orElse(null);
    }

    @PostMapping
    public Exercise createExercise(@RequestBody Exercise exercise) {
        return exerciseRepository.save(exercise);
    }

    @PutMapping("/{id}")
    public Exercise updateExercise(@PathVariable Long id, @RequestBody Exercise updatedExercise) {
        return exerciseRepository.findById(id)
                .map(exercise -> {
                    exercise.setName(updatedExercise.getName());
                    exercise.setTargetMuscle(updatedExercise.getTargetMuscle());
                    exercise.setEquipment(updatedExercise.getEquipment());
                    exercise.setBodyPart(updatedExercise.getBodyPart());
                    exercise.setGifUrl(updatedExercise.getGifUrl());
                    return exerciseRepository.save(exercise);
                })
                .orElse(null);
    }

    @DeleteMapping("/{id}")
    public void deleteExercise(@PathVariable Long id) {
        exerciseRepository.deleteById(id);
    }
}
