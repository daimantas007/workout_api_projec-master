package lt.viko.eif.grupe.sport_api.model;

import jakarta.persistence.*;
import lombok.*;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;


@Entity
@Table(name = "workout_items")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class WorkoutItem {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private int sets;
    private int reps;
    private double weight;

    private int durationMin;
    private double met;

    @ManyToOne
    @JoinColumn(name = "workout_id")
    @JsonIgnoreProperties("items")
    private Workout workout;


    @ManyToOne
    @JoinColumn(name = "exercise_id")
    private Exercise exercise;
}
