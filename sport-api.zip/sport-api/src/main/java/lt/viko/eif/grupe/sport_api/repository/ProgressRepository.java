package lt.viko.eif.grupe.sport_api.repository;

import lt.viko.eif.grupe.sport_api.model.Progress;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProgressRepository extends JpaRepository<Progress, Long> {
}
