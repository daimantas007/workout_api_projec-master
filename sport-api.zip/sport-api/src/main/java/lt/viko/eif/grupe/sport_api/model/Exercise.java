package lt.viko.eif.grupe.sport_api.model;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "exercises")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Exercise {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;

    private String targetMuscle;

    private String equipment;

    private String bodyPart;

    private String gifUrl;
}
