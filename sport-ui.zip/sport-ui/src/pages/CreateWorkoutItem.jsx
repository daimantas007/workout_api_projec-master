import { useState, useEffect } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import ExerciseDropdown from "../components/ExerciseDropdown";

function CreateWorkoutItem() {
  const [sets, setSets] = useState(0);
  const [reps, setReps] = useState(0);
  const [weight, setWeight] = useState(0);
  const [exerciseName, setExerciseName] = useState("");
  const [workoutId, setWorkoutId] = useState("");

  const navigate = useNavigate();
  const location = useLocation();

  // Gauti workoutId iš URL query
  useEffect(() => {
    const params = new URLSearchParams(location.search);
    const workoutIdFromURL = params.get("workoutId");
    if (workoutIdFromURL) {
      setWorkoutId(workoutIdFromURL);
    }
  }, [location.search]);

  const handleSubmit = (e) => {
    e.preventDefault();

    if (!exerciseName || !workoutId) {
      alert("Please select an exercise and ensure workout ID is set.");
      return;
    }

    const itemDTO = {
      sets: parseInt(sets),
      reps: parseInt(reps),
      weight: parseFloat(weight),
      workoutId: parseInt(workoutId),        // ✅ <- taip, kaip backend laukia
      exerciseName: exerciseName
    };

    fetch("http://localhost:8080/workout-items", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(itemDTO),
    })
      .then((res) => {
        if (!res.ok) throw new Error("Request failed");
        return res.json();
      })
      .then(() => {
        alert("Workout item created!");
        navigate("/workouts");
      })
      .catch((err) => console.error("Failed to create workout item:", err));
  };

  return (
    <div>
      <h2>Create Workout Item</h2>
      <form onSubmit={handleSubmit}>
        <ExerciseDropdown onSelect={setExerciseName} /><br />

        <label>Sets:</label><br />
        <input type="number" value={sets} onChange={(e) => setSets(e.target.value)} /><br />

        <label>Reps:</label><br />
        <input type="number" value={reps} onChange={(e) => setReps(e.target.value)} /><br />

        <label>Weight (kg):</label><br />
        <input type="number" value={weight} onChange={(e) => setWeight(e.target.value)} /><br />

        <button type="submit">Create Item</button>
      </form>
    </div>
  );
}

export default CreateWorkoutItem;
