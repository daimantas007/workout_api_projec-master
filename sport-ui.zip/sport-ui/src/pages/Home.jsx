function Home() {
    const userEmail = localStorage.getItem('userEmail');
  
    return (
      <div>
        <h2>Welcome to Sport Tracker!</h2>
        {userEmail ? (
          <p>Logged in as: {userEmail}</p>
        ) : (
          <p>You are not logged in.</p>
        )}
      </div>
    );
  }
  
  export default Home;
  