// src/pages/SearchExercises.jsx
import { useState } from 'react';

function SearchExercises() {
  const [muscleGroup, setMuscleGroup] = useState('');
  const [results, setResults] = useState([]);

  const handleSearch = async () => {
    const res = await fetch(`http://localhost:8001/exercises/search?muscleGroup=${muscleGroup}`);
    const data = await res.json();
    setResults(data);
  };

  return (
    <div>
      <h2>Search Exercises</h2>
      <input
        value={muscleGroup}
        onChange={(e) => setMuscleGroup(e.target.value)}
        placeholder="e.g. chest, biceps"
      />
      <button onClick={handleSearch}>Search</button>

      <ul>
        {results.map((ex) => (
          <li key={ex.id}>{ex.name}</li>
        ))}
      </ul>
    </div>
  );
}

export default SearchExercises;
