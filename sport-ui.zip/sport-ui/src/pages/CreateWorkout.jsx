import { useState } from "react";
import { useNavigate } from "react-router-dom";

function CreateWorkout() {
  const [title, setTitle] = useState("");
  const navigate = useNavigate();

  const handleSubmit = async (e) => {
    e.preventDefault();

    const userId = localStorage.getItem("userId");

    if (!userId) {
      alert("User is not logged in!");
      return;
    }

    const workout = {
      title,
      date: new Date().toISOString(),
      user: { id: userId }
    };

    try {
      const response = await fetch("http://localhost:8080/workouts", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(workout),
      });

      const createdWorkout = await response.json();

      alert("Workout created!");
      navigate(`/workout-items/create?workoutId=${createdWorkout.id}`);
    } catch (err) {
      console.error("Failed to create workout:", err);
      alert("Failed to create workout.");
    }
  };

  return (
    <div>
      <h2>Create Workout</h2>
      <form onSubmit={handleSubmit}>
        <input
          type="text"
          placeholder="Workout Title"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
        /><br />
        <button type="submit">Create</button>
      </form>
    </div>
  );
}

export default CreateWorkout;
