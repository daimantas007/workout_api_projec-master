import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";

function Workouts() {
  const [workouts, setWorkouts] = useState([]);
  const navigate = useNavigate();

  useEffect(() => {
    const userId = localStorage.getItem("userId");

    if (!userId) {
      alert("User not logged in");
      return;
    }

    fetch(`http://localhost:8080/workouts/user/${userId}`)
      .then((res) => {
        if (!res.ok) throw new Error("Failed to fetch workouts");
        return res.json();
      })
      .then((data) => setWorkouts(data))
      .catch((err) => console.error("Error loading workouts:", err));
  }, []);

  const handleDelete = (id) => {
    if (!window.confirm("Are you sure you want to delete this workout?")) return;

    fetch(`http://localhost:8080/workouts/${id}`, {
      method: "DELETE",
    })
      .then(() => {
        alert("Workout deleted!");
        setWorkouts((prev) => prev.filter((w) => w.id !== id));
      })
      .catch((err) => console.error("Failed to delete workout:", err));
  };

  const handleInspect = (id) => {
    navigate(`/workouts/${id}`);
  };

  const handleAddItem = (workoutId) => {
    navigate(`/workout-items/create?workoutId=${workoutId}`);
  };

  return (
    <div>
      <h2>Your Workouts</h2>
      <button onClick={() => navigate("/workouts/create")}>Create Workout</button>
      <ul>
        {workouts.map((workout) => (
          <li key={workout.id}>
            <strong>{workout.title}</strong> ({new Date(workout.date).toLocaleString()}){" "}
            <button onClick={() => handleInspect(workout.id)}>Inspect</button>{" "}
            <button onClick={() => handleDelete(workout.id)}>Delete</button>{" "}
            <button onClick={() => handleAddItem(workout.id)}>Add Workout Item</button>
          </li>
        ))}
      </ul>
    </div>
  );
}

export default Workouts;
