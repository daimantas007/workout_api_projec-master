import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";

function InspectWorkout() {
  const { id } = useParams();
  const [workout, setWorkout] = useState(null);
  const [items, setItems] = useState([]);

  useEffect(() => {
    // Gauti workout info
    fetch(`http://localhost:8080/workouts/${id}`)
      .then((res) => res.json())
      .then((data) => setWorkout(data))
      .catch((err) => console.error("Failed to fetch workout:", err));

    // Gauti workout itemus
    fetch(`http://localhost:8080/workout-items`)
      .then((res) => res.json())
      .then((data) => {
        const filtered = data.filter((item) => item.workout.id === parseInt(id));
        setItems(filtered);
      })
      .catch((err) => console.error("Failed to fetch workout items:", err));
  }, [id]);

  if (!workout) return <p>Loading...</p>;

  return (
    <div>
      <h2>Workout: {workout.title}</h2>
      <p>Date: {new Date(workout.date).toLocaleString()}</p>

      <h3>Exercises:</h3>
      <ul>
        {items.length === 0 && <li>No items found</li>}
        {items.map((item) => (
          <li key={item.id}>
            {item.exercise?.name || "Unnamed exercise"} – {item.sets} sets x {item.reps} reps, {item.weight} kg
          </li>
        ))}
      </ul>
    </div>
  );
}

export default InspectWorkout;
