import { useState } from 'react';

function Login() {
  const [form, setForm] = useState({
    email: '',
    password: ''
  });

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    const response = await fetch('http://localhost:8080/auth/login', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(form)
    });

    if (!response.ok) {
      alert("Login failed");
      return;
    }

    const user = await response.json();

    // Saugojam vartotojo ID ir email į localStorage
    localStorage.setItem('userId', user.id);
    localStorage.setItem('userEmail', user.email);

    alert("Login successful");
    window.location.href = '/';
  };

  return (
    <div>
      <h2>Login</h2>
      <form onSubmit={handleSubmit}>
        <input
          name="email"
          type="email"
          placeholder="Email"
          value={form.email}
          onChange={handleChange}
        /><br />
        <input
          name="password"
          type="password"
          placeholder="Password"
          value={form.password}
          onChange={handleChange}
        /><br />
        <button type="submit">Login</button>
      </form>
    </div>
  );
}

export default Login;
