function Progress() {
    return (
      <div>
        <h2>Progress</h2>
        <p>This will show workout progress and charts.</p>
      </div>
    );
  }
  export default Progress;
  