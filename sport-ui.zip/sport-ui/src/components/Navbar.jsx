import { Link, useNavigate } from "react-router-dom";
import { useEffect, useState } from "react";

function Navbar() {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    const userId = localStorage.getItem("userId");
    setIsLoggedIn(!!userId); // true jei prisijungęs
  }, []);

  const handleLogout = () => {
    localStorage.removeItem("userId");
    localStorage.removeItem("userEmail");
    setIsLoggedIn(false);
    navigate("/login");
  };

  return (
    <nav style={{ marginBottom: "1rem" }}>
      <Link to="/">Home</Link>{" | "}
      {!isLoggedIn && <Link to="/register">Register</Link>}{" "}
      {!isLoggedIn && <Link to="/login">Login</Link>}{" "}
      {isLoggedIn && <Link to="/users">Users</Link>}{" "}
      <Link to="/workouts">Workouts</Link>{" | "}
      <Link to="/progress">Progress</Link>{" | "}
      <Link to="/search-exercises">Exercise Search</Link>{" | "}
      {isLoggedIn && (
        <button onClick={handleLogout} style={{ marginLeft: "1rem" }}>
          Logout
        </button>
      )}
    </nav>
  );
}

export default Navbar;
