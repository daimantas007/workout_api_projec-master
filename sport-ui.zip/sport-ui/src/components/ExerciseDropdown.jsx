import { useEffect, useState } from "react";

function ExerciseDropdown({ onSelect }) {
  const [muscleGroup, setMuscleGroup] = useState("glutes");
  const [exercises, setExercises] = useState([]);
  const [selectedExercise, setSelectedExercise] = useState("");

  useEffect(() => {
    if (!muscleGroup) return;

    fetch(`http://localhost:8001/exercises/search?muscleGroup=${muscleGroup}`)
      .then((res) => res.json())
      .then((data) => setExercises(data))
      .catch((err) => console.error("Failed to fetch exercises:", err));
  }, [muscleGroup]);

  const handleExerciseChange = (e) => {
    const selectedName = e.target.options[e.target.selectedIndex].text;
    setSelectedExercise(selectedName);
    onSelect(selectedName); // perduodam į tėvinį komponentą
  };

  const muscleGroups = ["biceps", "triceps", "quads", "hamstrings", "calves", "abs"];

  return (
    <div>
      <label>Muscle group: </label>
      <select onChange={(e) => setMuscleGroup(e.target.value)} value={muscleGroup}>
        {muscleGroups.map((group) => (
          <option key={group} value={group}>
            {group}
          </option>
        ))}
      </select>

      <br />

      <label>Select exercise: </label>
      <select onChange={handleExerciseChange} value={selectedExercise}>
        <option value="">-- Choose exercise --</option>
        {exercises.map((exercise) => (
          <option key={exercise.id} value={exercise.name}>
            {exercise.name}
          </option>
        ))}
      </select>
    </div>
  );
}

export default ExerciseDropdown;
