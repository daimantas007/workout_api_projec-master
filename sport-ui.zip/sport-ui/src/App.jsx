import { Routes, Route } from 'react-router-dom';
import Navbar from './components/Navbar'; 
import Home from './pages/Home';
import Users from './pages/Users';
import Register from './pages/Register';
import Login from './pages/Login';
import Workouts from './pages/Workouts';
import Progress from './pages/Progress';
import SearchExercises from './pages/SearchExercises';
import CreateWorkout from './pages/CreateWorkout';
import CreateWorkoutItem from "./pages/CreateWorkoutItem";
import InspectWorkout from './pages/InspectWorkout';




function App() {
  return (
    <div>
      <Navbar /> {/* ← Rodo visada */}
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/users" element={<Users />} />
        <Route path="/register" element={<Register />} />
        <Route path="/login" element={<Login />} />
        <Route path="/workouts" element={<Workouts />} />
        <Route path="/progress" element={<Progress />} />
        <Route path="/search-exercises" element={<SearchExercises />} />
        <Route path="/workouts/create" element={<CreateWorkout />} />
        <Route path="/workout-items/create" element={<CreateWorkoutItem />} />
        <Route path="/workouts/:id" element={<InspectWorkout />} />

      </Routes>
    </div>
  );
}

export default App;
