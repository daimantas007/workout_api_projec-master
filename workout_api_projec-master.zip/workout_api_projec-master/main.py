# main.py
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from dotenv import load_dotenv

from routers.progress import progress_router
from routes.exercises import exercises_router
from routes.workouts import workouts_router

# Įkeliam .env failo turinį
load_dotenv()

app = FastAPI()

# CORS leidžia frontend (React) jungtis prie API
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:5173"],  # React dev server
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Registruojam maršrutus
app.include_router(progress_router)      # /progress/today
app.include_router(exercises_router)     # /exercises/search
app.include_router(workouts_router)      # /workouts/{id}/summary

# ⬇️ Paleidimo blokas, kad veiktų su Run/Debug
if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="127.0.0.1", port=8001, reload=True)
